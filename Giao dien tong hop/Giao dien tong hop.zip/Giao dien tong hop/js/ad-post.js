$(document).ready(function () {
  autosize($('.comment-input > textarea'));
});
